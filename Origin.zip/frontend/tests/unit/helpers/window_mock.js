// window is already mocked but not every part of it
global.scroll = jest.fn()
global.open = jest.fn()
