export const addresses = [`AddressA`, `AddressB`]

export const validators = [
  `CosmosValidatorAddress1`,
  `CosmosValidatorAddress2`,
  `CosmosValidatorAddress3`
]
