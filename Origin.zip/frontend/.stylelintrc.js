module.exports = {
  root: true,
  'extends': 'stylelint-config-standard',
  'color-no-invalid-hex': true,
  'font-family-no-duplicate-names': true
}
