declare module 'graphql' {
  const z: any;
  export default z;
}