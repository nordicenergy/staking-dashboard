declare module 'vue-infinite-scroll' {
  const z: any;
  export default z;
}
