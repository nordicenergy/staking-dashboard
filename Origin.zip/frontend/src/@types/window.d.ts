declare global {
  interface Window {
    store: any;
  }
}
