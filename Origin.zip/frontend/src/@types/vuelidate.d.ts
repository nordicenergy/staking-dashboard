declare module 'vuelidate' {
  const z: any;
  export default z;
}
