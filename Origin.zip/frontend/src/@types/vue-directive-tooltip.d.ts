declare module 'vue-directive-tooltip' {
  const z: any;
  export default z;
}