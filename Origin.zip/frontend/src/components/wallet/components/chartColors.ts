export const chartColors = [
  "#2077FF",
  "#00C4CC",
  "#B8D4E3",
  "#f5f775",
  "#E53737",
  "#EEFFDB"
]
