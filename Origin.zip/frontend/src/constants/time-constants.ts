export const SECONDS_PER_EPOCH = 60 * 60 * 24

export const POLLING_TIMEOUT_SEC = 5