module.exports = {
  connected: true,
  network: 'Test Network',
  lastHeader: {
    chain_id: 'cosmoshub-2',
    height: '2377566'
  }
};
