module.exports = {
  not_bonded_tokens: "65805820143728",
  bonded_tokens: "180750373903450"
};
