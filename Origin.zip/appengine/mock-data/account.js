module.exports = {
  type: 'auth/Account',
  value: {
    address: 'one10a6tld9lwkp4fnfxgvx7ptv0haqz747kgj6jzd',
    coins: [{ denom: 'one', amount: '7550000' }],
    public_key: {
      type: 'tendermint/PubKeySecp256k1',
      value: 'A3Au1T7dOrrui03yqIVtDGev+iWlDTwZ7dpx9M4LePk9'
    },
    account_number: '22147',
    sequence: '2'
  }
};

// const temp = {
//   type: "auth/Account",
//   value: {
//     address: "cosmos1r5fknqx36n8vts9wlqufw08u3fh3qklhfwvhg5",
//     coins: [{ denom: "one", amount: "7000000" }],
//     public_key: null,
//     account_number: "22147",
//     sequence: "0"
//   }
// };
