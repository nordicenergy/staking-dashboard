// minting/annual-provisions
module.exports = "18240689989533.703492076078609840"
