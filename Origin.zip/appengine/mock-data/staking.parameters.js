module.exports = {
    unbonding_time: "1814400000000000",
    max_validators: 100,
    max_entries: 7,
    bond_denom: "one"
};